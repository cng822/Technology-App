package com.example.technology;

public class Laptops extends Technology {
    public Laptops(String productName, String category, int image, int price){
        super(productName, category, image, price);
    }

    public String getName() { return this.productName; }

    public String getCategory() { return this.category; }

    public int getPrice() { return this.price; }

    public int getImage() { return this.image; }
}
