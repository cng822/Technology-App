package com.example.technology;

public class Technology {
    private String productName;
    private String category;
    private int image;
    private int price;

    public Technology(String productName, String category, int image, int price) {
        this.productName = productName;
        this.category = category;
        this.image = image;
        this.price = price;
    }

    public String getName() { return this.productName; }

    public String getCategory() { return this.category; }

    public int getPrice() { return this.price; }

    public int getImage() { return this.image; }

}
