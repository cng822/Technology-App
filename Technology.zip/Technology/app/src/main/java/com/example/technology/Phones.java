package com.example.technology;

public class Phones extends Technology {

    public Phones(String productName, String category, int image, String price){
        super(productName, category, image, price);
    }

    public String getName() { return this.productName; }

    public String getCategory() { return this.category; }

    public String getPrice() { return this.price; }

    public int getImage() { return this.image; }
}
