package com.example.technology;


import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.ArrayList;

public class TechnologyAdapter extends RecyclerView.Adapter<TechnologyAdapter.ViewHolder> {

    private ArrayList<Technology> tech;
    private Context aContext;

    public TechnologyAdapter(Context context, ArrayList<Technology> objects){
        this.tech = objects;
        this.aContext = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int position){
        View view = LayoutInflater.from(aContext).inflate(R.layout.activity_list__view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        Technology currentProduct = tech.get(position);
        viewHolder.tvTitle.setText(currentProduct.getName());
        viewHolder.ivCover.setImageResource(currentProduct.getImage());

    }

    @Override
    public int getItemCount() {
        return tech.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView ivCover;
        TextView tvTitle;
        public ViewHolder(@NonNull View item){
            super(item);
            ivCover = item.findViewById(R.id.ivCover);
            tvTitle = item.findViewById(R.id.tvTitle);

            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v){
                    Intent select = new Intent(v.getContext(), DetailActivity.class);
                    select.putExtra("name", tech.get(getAdapterPosition()).getName());
                    select.putExtra("image", tech.get(getAdapterPosition()).getImage());
                    select.putExtra("price", tech.get(getAdapterPosition()).getPrice());
                    v.getContext().startActivity(select);
                }

            }
            );
        }
    }

}

