package com.example.technology;

import android.content.Context;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class TechnologyAdapter extends ArrayAdapter {

    int resources;
    ArrayList<Technology> tech;
    Context aContext;
    public TechnologyAdapter(@NonNull Context context, int resource, @NonNull ArrayList objects) {
        super(context, resource, objects);
        resources = resource;
        tech = objects;
        aContext = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
//Get a reference to the current ListView item
        View currentListViewItem = convertView;

        // Check if the existing view is being reused, otherwise inflate the view
        if (currentListViewItem == null) {
            currentListViewItem = LayoutInflater.from(getContext()).inflate(resources, parent, false);
        }
        //Get the Number object for the current position
        Technology currentProduct = tech.get(position);

        //Set the attributed of list_view_number_item views
        ImageView iconImageView = (ImageView) currentListViewItem.findViewById(R.id.ivCover);
        int i = currentProduct.getImage();

        //Setting the icon
        iconImageView.setImageResource(i);

        TextView NameTextView = (TextView) currentListViewItem.findViewById(R.id.tvTitle);
        NameTextView.setText(currentProduct.getName());
        return currentListViewItem;
    }
}
