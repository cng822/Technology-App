package com.example.technology;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        //Testing the dictionary
        ArrayList<Technology> techList = DataProvider.generateData();
        TechnologyAdapter technologyAdapter = new TechnologyAdapter(this, R.layout.activity_list__view,
                techList);
        ListView listView = (ListView) findViewById(R.id.RecylcerView);
        listView.setAdapter(technologyAdapter);
    }
}