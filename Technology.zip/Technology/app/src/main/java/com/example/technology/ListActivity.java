package com.example.technology;

import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {
    TechnologyAdapter technologyAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        ArrayList<Technology> techList = DataProvider.generateData();
        RecyclerView recyclerView = findViewById(R.id.RecylcerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        technologyAdapter = new TechnologyAdapter(this, techList);
        recyclerView.setAdapter(technologyAdapter);
    }
}