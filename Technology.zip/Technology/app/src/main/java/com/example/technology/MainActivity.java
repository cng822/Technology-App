package com.example.technology;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CardView PHCardView = (CardView) findViewById(R.id.phone_view);
        PHCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent phoneIntent = new Intent(getBaseContext(), ListActivity.class);
                startActivity(phoneIntent);
            }
        });
        CardView LTCardView = (CardView) findViewById(R.id.laptops_view);
        LTCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent laptopsIntent = new Intent(getBaseContext(), ListActivity.class);
                startActivity(laptopsIntent);
            }
        });
        CardView SWCardView = (CardView) findViewById(R.id.watches_view);
        SWCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent watchesIntent = new Intent(getBaseContext(), ListActivity.class);
                startActivity(watchesIntent);
            }
        });

    }
}
