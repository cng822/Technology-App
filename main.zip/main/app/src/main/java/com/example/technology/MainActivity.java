package com.example.technology;

import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity{

    TopViewAdapter picksadapter;
    List<Technology> picks;
    TechnologyAdapter sAdapter;
    List<Technology> searchList;
    RecyclerView recyclerSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CardView PHCardView = (CardView) findViewById(R.id.phone_view);
        PHCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent phoneIntent = new Intent(getBaseContext(), ListActivity.class);
                phoneIntent.putExtra("category", "Phones");
                startActivity(phoneIntent);
            }
        });

        CardView LTCardView = (CardView) findViewById(R.id.laptops_view);
        LTCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent laptopsIntent = new Intent(getBaseContext(), ListActivity.class);
                laptopsIntent.putExtra("category", "Laptops");
                startActivity(laptopsIntent);
            }
        });

        CardView WatchesCardView = (CardView) findViewById(R.id.view_watch);
        WatchesCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent watchIntent = new Intent(getBaseContext(), ListActivity.class);
                watchIntent.putExtra("category", "Smart Watches");
                startActivity(watchIntent);
            }
        });

        setUpTopPicks();
        // search
        // Locate the Recycler View
//        recyclerSearch = findViewById(R.id.RecylcerView);
//        searchList = DataProvider.generateData();
//        sAdapter = new TechnologyAdapter(this, searchList);
//        recyclerSearch.setAdapter(sAdapter);
//
//        SearchView searchView = (SearchView) findViewById(R.id.filterSearch);
//        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//            @Override
//            public boolean onQueryTextSubmit(String query) {
//                return false;
//            }
//
//            @Override
//            public boolean onQueryTextChange(String newText) {
//                sAdapter.getFilter().filter(newText);
//                return false;
//            }
//        });

//        recyclerSearch.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(MainActivity.this, movieNamesArrayList.get(position).getAnimalName(), Toast.LENGTH_SHORT).show();
//            }
//        });
    }

    private void setUpTopPicks() {
        RecyclerView recyclerView = findViewById(R.id.top3);
        picks = TopViewProvider.top3();
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);
        picksadapter = new TopViewAdapter(this, picks);
        recyclerView.setAdapter(picksadapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.searchbar, menu);
        final MenuItem searchItem = menu.findItem(R.id.searchMenuMain);
        final SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                Intent intent = new Intent(getBaseContext(), SearchActivity.class);
                intent.putExtra("search", query);
                startActivity(intent);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });
        return true;
    }


}